import bpy


class HEIGHTMAP_PT_main(bpy.types.Panel):

    bl_label = "Mesh From CAD Points"

    bl_idname = "HEIGHTMAP_PT_main"

    bl_space_type = "VIEW_3D"

    bl_region_type = "UI"

    bl_category = "HeightMap"


    def draw(self, context):

        layout = self.layout

        s = context.scene.heightmap

        # ----------------------------------------------------
        # Point filtering
        # ----------------------------------------------------

        box = layout.box()

        box.label(text="Point Filtering", icon='FILTER')

        row = box.row()

        row.prop(s, "use_range_filter")

        sub = box.row(align=True)

        sub.enabled = s.use_range_filter

        sub.prop(s, "min_height", text="Min")

        sub.prop(s, "max_height", text="Max")

        # ----------------------------------------------------
        # Mesh generation
        # ----------------------------------------------------

        box = layout.box()

        box.label(text="Mesh Generation", icon='MESH_DATA')

        box.prop(s, "mesh_method", text="")

        if s.mesh_method == "GRID":

            row = box.row(align=True)

            row.prop(s, "grid_x", text="X")

            row.prop(s, "grid_y", text="Y")

        # ----------------------------------------------------
        # Result
        # ----------------------------------------------------

        box = layout.box()

        box.label(text="Result", icon='OBJECT_DATA')

        box.prop(s, "result_name", text="")

        # ----------------------------------------------------
        # Buttons
        # ----------------------------------------------------

        layout.separator()

        layout.operator(
            "heightmap.preview",
            icon='RESTRICT_SELECT_OFF'
        )

        layout.operator(
            "heightmap.build",
            icon='SURFACE_NSURFACE',
            text="Build Mesh"
        )


classes = (
    HEIGHTMAP_PT_main,
)