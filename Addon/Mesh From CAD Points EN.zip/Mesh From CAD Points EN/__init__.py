bl_info = {
    "name":        "Mesh From CAD Points",
    "author":      "MoskovkinR",
    "version":     (1, 0, 0),
    "blender":     (3, 0, 0),
    "location":    "3D Viewport → N-Panel → HeightMap",
    "description": "Generate terrain mesh from CAD elevation text points (FONT objects)",
    "category":    "Mesh",
}

import bpy
from bpy.props import (
    BoolProperty,
    FloatProperty,
    EnumProperty,
    IntProperty,
    StringProperty,
)
from bpy.types import PropertyGroup

from . import operators, panels


# ============================================================
#  Addon settings — stored in Scene
# ============================================================
class HeightMapSettings(PropertyGroup):

    # --- Range filter ---
    use_range_filter: BoolProperty(
        name="Use Range Filter",
        description="Use only points inside Min / Max range",
        default=True,
    )

    min_height: FloatProperty(
        name="Min",
        description="Minimum elevation value",
        default=120.0,
        precision=2,
    )

    max_height: FloatProperty(
        name="Max",
        description="Maximum elevation value",
        default=140.0,
        precision=2,
    )

    # --- Mesh generation method ---
    mesh_method: EnumProperty(
        name="Method",
        description="Surface generation algorithm",
        items=[
            ("DELAUNAY", "Delaunay (TIN)", "Accurate triangulation from source points"),
            ("GRID",     "Grid", "Regular grid using nearest point elevation"),
        ],
        default="DELAUNAY",
    )

    grid_x: IntProperty(
        name="Grid X",
        default=10,
        min=2,
        max=500,
    )

    grid_y: IntProperty(
        name="Grid Y",
        default=10,
        min=2,
        max=500,
    )

    # --- Result object name ---
    result_name: StringProperty(
        name="Object Name",
        description="Generated mesh object name",
        default="TerrainMesh",
    )


# ============================================================
#  Registration
# ============================================================
classes = (
    HeightMapSettings,
    *operators.classes,
    *panels.classes,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.heightmap = bpy.props.PointerProperty(
        type=HeightMapSettings
    )


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.heightmap