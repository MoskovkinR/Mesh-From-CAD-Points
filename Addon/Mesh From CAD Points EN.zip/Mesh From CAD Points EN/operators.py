import bpy
import re


# ============================================================
#  Delaunay triangulation (Bowyer-Watson)
# ============================================================

def _circumcircle(i, j, k, pts):
    ax, ay = pts[i][0], pts[i][1]
    bx, by = pts[j][0], pts[j][1]
    cx, cy = pts[k][0], pts[k][1]

    d = 2.0 * (ax*(by-cy) + bx*(cy-ay) + cx*(ay-by))

    if abs(d) < 1e-12:
        return None

    a2 = ax*ax + ay*ay
    b2 = bx*bx + by*by
    c2 = cx*cx + cy*cy

    ux = (a2*(by-cy) + b2*(cy-ay) + c2*(ay-by)) / d
    uy = (a2*(cx-bx) + b2*(ax-cx) + c2*(bx-ax)) / d

    return ux, uy, (ax-ux)**2 + (ay-uy)**2


def delaunay_triangulate(pts):

    n = len(pts)

    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]

    delta = max(max(xs)-min(xs), max(ys)-min(ys)) or 1.0

    mx = (min(xs) + max(xs)) / 2
    my = (min(ys) + max(ys)) / 2

    # Super triangle
    st = [
        (mx - 20*delta, my - delta),
        (mx,             my + 20*delta),
        (mx + 20*delta,  my - delta),
    ]

    all_pts = list(pts) + st

    i0, i1, i2 = n, n+1, n+2

    c = _circumcircle(i0, i1, i2, all_pts)

    triangles = [[i0, i1, i2, c[0], c[1], c[2]]]

    for ip in range(n):

        p = all_pts[ip]

        bad = [
            t for t in triangles
            if (p[0]-t[3])**2 + (p[1]-t[4])**2 <= t[5]
        ]

        edges = []

        for t in bad:

            for e in ((t[0],t[1]), (t[1],t[2]), (t[2],t[0])):

                rev = (e[1], e[0])

                if rev in edges:
                    edges.remove(rev)
                else:
                    edges.append(e)

        triangles = [t for t in triangles if t not in bad]

        for a, b in edges:

            c = _circumcircle(a, b, ip, all_pts)

            if c:
                triangles.append([a, b, ip, c[0], c[1], c[2]])

    return [
        (t[0], t[2], t[1])
        for t in triangles
        if t[0] < n and t[1] < n and t[2] < n
    ]


# ============================================================
#  Geometry generation
# ============================================================

def build_delaunay(points):

    tris = delaunay_triangulate(points)

    verts = [(p[0], p[1], p[2]) for p in points]

    return verts, [], tris


def build_grid(points, gx, gy):

    xs = [p[0] for p in points]
    ys = [p[1] for p in points]

    x0, x1 = min(xs), max(xs)
    y0, y1 = min(ys), max(ys)

    sx = (x1 - x0) / gx
    sy = (y1 - y0) / gy

    verts = []

    for i in range(gx + 1):
        for j in range(gy + 1):

            x = x0 + i * sx
            y = y0 + j * sy

            z = min(
                points,
                key=lambda p, x=x, y=y:
                (p[0]-x)**2 + (p[1]-y)**2
            )[2]

            verts.append((x, y, z))

    faces = []

    cols = gy + 1

    for i in range(gx):
        for j in range(gy):

            v1 = i * cols + j

            faces.append((
                v1,
                v1 + cols,
                v1 + 1 + cols,
                v1 + 1
            ))

    return verts, [], faces


# ============================================================
#  Collect elevation points from scene
# ============================================================

_PATTERN = re.compile(r'^\d+(\.\d+)?$')


def collect_points(settings):

    points = []

    skipped_format = 0
    skipped_range = 0

    for obj in bpy.context.scene.objects:

        if obj.type != 'FONT':
            continue

        text = obj.data.body.strip()

        if not _PATTERN.match(text):
            skipped_format += 1
            continue

        try:
            value = float(text)

        except ValueError:
            skipped_format += 1
            continue

        if settings.use_range_filter:

            if not (
                settings.min_height <= value <= settings.max_height
            ):
                skipped_range += 1
                continue

        points.append((
            obj.location.x,
            obj.location.y,
            value
        ))

    return points, skipped_format, skipped_range


# ============================================================
#  Build mesh operator
# ============================================================

class HEIGHTMAP_OT_build(bpy.types.Operator):

    bl_idname = "heightmap.build"

    bl_label = "Build Mesh"

    bl_description = (
        "Generate terrain mesh from text elevation points"
    )

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        s = context.scene.heightmap

        # 1. Collect points
        points, skip_fmt, skip_rng = collect_points(s)

        if len(points) < 3:

            self.report(
                {'ERROR'},
                f"Not enough points: {len(points)} "
                f"(invalid format: {skip_fmt}, "
                f"out of range: {skip_rng})"
            )

            return {'CANCELLED'}

        # 2. Build geometry
        if s.mesh_method == "DELAUNAY":

            verts, edges, faces = build_delaunay(points)

        else:

            verts, edges, faces = build_grid(
                points,
                s.grid_x,
                s.grid_y
            )

        # 3. Create / replace object
        name = s.result_name

        if name in bpy.data.objects:

            old = bpy.data.objects[name]

            bpy.data.meshes.remove(
                old.data,
                do_unlink=True
            )

        mesh = bpy.data.meshes.new(name)

        mesh.from_pydata(verts, edges, faces)

        mesh.update()

        obj_out = bpy.data.objects.new(name, mesh)

        context.collection.objects.link(obj_out)

        bpy.ops.object.select_all(action='DESELECT')

        obj_out.select_set(True)

        context.view_layer.objects.active = obj_out

        self.report(
            {'INFO'},
            f"Terrain generated: {len(points)} points, "
            f"{len(faces)} faces [{s.mesh_method}]"
        )

        return {'FINISHED'}


# ============================================================
#  Preview operator
# ============================================================

class HEIGHTMAP_OT_preview(bpy.types.Operator):

    bl_idname = "heightmap.preview"

    bl_label = "Preview Points"

    bl_description = (
        "Highlight valid elevation text objects in the scene"
    )

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        s = context.scene.heightmap

        points, skip_fmt, skip_rng = collect_points(s)

        bpy.ops.object.select_all(action='DESELECT')

        _PATTERN_local = re.compile(r'^\d+(\.\d+)?$')

        selected = 0

        for obj in context.scene.objects:

            if obj.type != 'FONT':
                continue

            text = obj.data.body.strip()

            if not _PATTERN_local.match(text):
                continue

            try:
                value = float(text)

            except ValueError:
                continue

            if (
                s.use_range_filter and
                not (s.min_height <= value <= s.max_height)
            ):
                continue

            obj.select_set(True)

            selected += 1

        self.report(
            {'INFO'},
            f"Selected {selected} points "
            f"(invalid: {skip_fmt}, "
            f"out of range: {skip_rng})"
        )

        return {'FINISHED'}


# ============================================================

classes = (
    HEIGHTMAP_OT_build,
    HEIGHTMAP_OT_preview,
)